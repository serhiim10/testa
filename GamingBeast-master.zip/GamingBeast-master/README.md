# GamingBeast
This is a open source mini gaming website using js

## Getting Started
1. Make sure you have a <a href="https://github.com">GitHub</a> Account.
2. Make sure <a href="https://github.com">VS code</a> is installed on your system.
3. Make sure you have <a href="https://git-scm.com/downloads">Git</a> installed on your system.
4. <a href="https://docs.github.com/en/get-started/quickstart/fork-a-repo">Fork</a> the repository on GitHub.


## Making Changes
1. Create a Branch for your changes.
2. Commit Your Code for each  change 
3. Push your change to your fork.
4. Create a Pull Request on GitHub for your change.
5. Wait for reviewers to give feedback.
